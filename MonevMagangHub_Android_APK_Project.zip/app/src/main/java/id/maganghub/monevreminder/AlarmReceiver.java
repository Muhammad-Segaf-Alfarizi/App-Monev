package id.maganghub.monevreminder;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.net.URLEncoder;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "monev_maganghub_channel";

    @Override
    public void onReceive(Context context, Intent intent) {
        String sessionLabel = intent.getStringExtra("SESSION_LABEL");
        if (sessionLabel == null) sessionLabel = "Jadwal Presensi";
        String phone = "62895394853580";

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Pengingat Presensi Monev MagangHub",
                NotificationManager.IMPORTANCE_HIGH
            );
            nm.createNotificationChannel(channel);
        }

        String message = "Halo! Waktunya mengisi presensi Monev MagangHub (" + sessionLabel + "). Link: https://maganghub.kemnaker.go.id";
        String waUrl = "https://wa.me/" + phone + "?text=" + Uri.encode(message);

        Intent waIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(waUrl));
        PendingIntent waPendingIntent = PendingIntent.getActivity(
            context,
            (int) System.currentTimeMillis(),
            waIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Waktunya Presensi Monev (" + sessionLabel + ")")
            .setContentText("Ketuk untuk kirim pengingat ke WhatsApp (+62895394853580)")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(waPendingIntent);

        if (nm != null) {
            nm.notify((int) System.currentTimeMillis(), builder.build());
        }
    }
}
