# Paket Proyek Android (.APK) — Monev MagangHub Reminder

Nomor WhatsApp Anda (**`62895394853580`**) dan 3 jadwal harian (**12:00 Siang**, **15:30 Sore**, dan **20:00 Malam**) sudah terpasang langsung di dalam kode aplikasi ini.

Karena lingkungan server saat ini tidak memiliki *Android SDK binary compiler* untuk mengekspor file `.apk` mentah secara langsung, Anda dapat mengubah paket ini menjadi file `.apk` siap pasang di HP dalam **1 menit** melalui salah satu dari 3 cara berikut:

## Cara 1: Konversi Instan Tanpa Koding (1 Menit via WebIntoApp)
1. Ekstrak file ZIP ini, lalu ambil file **`index.html`**.
2. Buka situs gratis **[WebIntoApp - HTML to APK](https://www.webintoapp.com/html-to-app)**.
3. Klik **Upload HTML File** dan pilih file **`index.html`**.
4. Isi nama aplikasi **`Monev MagangHub Reminder`**, klik **Next**, lalu klik **Make App** untuk mengunduh file **`.apk`** Anda.

## Cara 2: Compile Native Android `.APK` Otomatis via GitHub (Tanpa Install Android Studio)
Di dalam folder ini sudah terdapat kode native Java Android (`MainActivity.java`, `AlarmReceiver.java`, `BootReceiver.java`) yang menggunakan `AlarmManager` Android:
1. Unggah isi folder ini ke repositori GitHub Anda.
2. Buka tab **Actions** di GitHub, lalu jalankan workflow **Build Monev Reminder APK**.
3. Dalam ~1 menit, unduh file **`MonevMagangHub-Reminder-62895394853580-APK`** yang sudah jadi.

## Cara 3: Buka di Android Studio
1. Buka folder ini di **Android Studio**.
2. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. File `.apk` akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.
